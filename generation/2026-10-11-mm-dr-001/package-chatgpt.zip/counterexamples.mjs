// GENERATED research checks. Runs literal upstream compose logic with mocked evidence.
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {compose} from './compose-under-test.mjs';

const entry=(id,claims={},input=['system-state'],output=['system-state'])=>({id,name:id,input:'synthetic input',output:'synthetic output',actsOn:{input,output},invariants:{preserved:[],broken:[],output:[],...claims}});
const parsed=(entries,ids,relations=[],carriers={"system-state":null})=>({entries,vocabulary:{INVARIANTS:ids.map(id=>({id,name:id,carrier:'system-state'})),RELATIONS:relations,CARRIERS:carriers}});
const results=[];

// Exact unary profiles do not determine exact profiles of composites.
const domain=[0,1,2], inv=x=>x===0, plus=x=>(x+1)%3, minus=x=>(x+2)%3;
const profile=fn=>({preserves:domain.every(x=>!inv(x)||inv(fn(x))),mayBreak:domain.some(x=>inv(x)&&!inv(fn(x))),creates:domain.every(x=>inv(fn(x)))});
assert.deepEqual(profile(plus),profile(minus));
assert.notDeepEqual(profile(x=>minus(plus(x))),profile(x=>plus(plus(x))));
results.push({case:'exact composite profiles need relational state information',step_profiles:{plus:profile(plus),minus:profile(minus)},composite_plus_minus:profile(x=>minus(plus(x))),composite_plus_plus:profile(x=>plus(plus(x))),settled:'identical preserved/may-break/creates step flags cannot determine an exact composite endpoint profile; neither chain preserves the invariant at every intermediate state'});

// P(s) := s===0, Q(s) := s<=1, f(0)=0 and f(s)=2 otherwise.
const states=[0,1,2], P=s=>s===0, Q=s=>s<=1, f=s=>s===0?0:2;
assert(states.every(s=>!P(s)||Q(s)));
assert(states.every(s=>!P(s)||P(f(s))));
assert(Q(1)&&!Q(f(1)));
const implication=compose(['f'],parsed([entry('f',{preserved:['P']})],['P','Q'],[{from:'P',to:'Q',kind:'implies'}]));
assert.equal(implication.invariants.find(x=>x.invariant==='Q').status,'survives');
results.push({case:'preservation implication is conditional on P',upstream_status:'Q survives',semantic_counterexample:{initial:1,final:f(1),Q_initial:Q(1),Q_final:Q(f(1))},settled:'P implies Q and preserves P do not establish preserves Q on all Q inputs'});

const breakClosure=compose(['f'],parsed([entry('f',{preserved:['P'],broken:['Q']})],['P','Q'],[{from:'P',to:'Q',kind:'implies'}]));
assert.equal(breakClosure.invariants.find(x=>x.invariant==='P').status,'broken');
results.push({case:'may-break implication closure',upstream_status:'P broken',semantic_fact:'f preserves P on every state in this domain',settled:'an existential Q-breaking witness need not satisfy P'});

const restoration=compose(['a','b','c'],parsed([entry('a',{broken:['X']}),entry('b',{output:['X']}),entry('c')],['X']));
assert.equal(restoration.invariants[0].status,'restored');
results.push({case:'silence after restoration',upstream_status:'restored',silent_step:'c',settled:'restored output alone does not prove subsequent preservation'});

const join=compose(['a','b'],parsed([entry('a',{},['system-state'],['system-state','unverified-data']),entry('b',{},['system-state','verified-signature'],['system-state'])],[],[],{'system-state':null,'unverified-data':null,'verified-signature':null}));
assert.equal(join.joins[0].status,'match');
results.push({case:'conjunctive operand joins',upstream_status:'match',missing_operand:'verified-signature',settled:'matching one carrier is insufficient when all input components are required; upstream arrays do not express this distinction'});

// Exact uniform two-bit enumeration: each share hides H, both shares determine H.
const samples=[];
for(const h of [0,1])for(const r of [0,1])samples.push({h,r,a:r,b:r^h});
const hist=(key,h)=>[0,1].map(v=>samples.filter(s=>s.h===h&&s[key]===v).length/2);
for(const key of ['a','b'])assert.deepEqual(hist(key,0),hist(key,1));
assert(samples.every(s=>(s.a^s.b)===s.h));
results.push({case:'aggregation of individually independent releases',samples,marginals:{a_given_H0:hist('a',0),a_given_H1:hist('a',1),b_given_H0:hist('b',0),b_given_H1:hist('b',1)},joint_decodes_secret:true,settled:'this does not refute composition of full-state relational NI; it refutes marginal-output summaries that forget correlation and prior observations'});

const fetches=h=>h?['GET /constant-image']:[];
assert.notDeepEqual(fetches(0),fetches(1));
results.push({case:'implicit control flow',constant_payload:'/constant-image',observations_H0:fetches(0),observations_H1:fetches(1),settled:'occurrence of an effect leaks a bit even if the payload has no secret origin'});

// A trace-safety violation cannot be undone by changing the final current state.
const trace=[{kind:'send',origins:['W'],destination:'outside-B'},{kind:'erase',location:'outside-B'}];
const good=t=>!t.some(e=>e.kind==='send'&&e.origins.includes('W')&&e.destination==='outside-B');
assert(!good(trace.slice(0,1))&&!good(trace));
results.push({case:'egress followed by erasure',current_state_can_be_local_again:true,policy_at_prefix:good(trace.slice(0,1)),policy_at_end:good(trace),settled:'state restoration does not restore a never-egress trace policy'});

// Same abstract operation, different handler destination.
const send=(h,v)=>({kind:'send',value:v,destination:h.destination});
assert.notEqual(send({destination:'inside-B'},'W-data').destination,send({destination:'outside-B'},'W-data').destination);
results.push({case:'context-dependent handler',same_operation:'send',inside:send({destination:'inside-B'},'W-data'),outside:send({destination:'outside-B'},'W-data'),settled:'a context-independent operation name does not determine the effect outcome'});

// Atomic commit checks differ from separate stale authorization checks.
const verified={record:'R',version:4,digest:'d',owner:'Alice',nonce:9};
const current={record:'R',version:5,digest:'d',owner:'Bob'};
assert(verified.digest===current.digest);
assert(verified.version!==current.version&&verified.owner!==current.owner);
results.push({case:'signature witness does not imply current owner authorization',cryptographic_bytes_still_valid:true,verified,current,settled:'the commit must bind the current owner and version atomically; a valid signature can be stale'});

// A signed instruction may be accepted twice by a stateless verifier.
const acceptedStateless=['signed-command-9','signed-command-9'];
assert(new Set(acceptedStateless).size<acceptedStateless.length);
results.push({case:'replay with valid signatures',verification_results:[true,true],freshness:false,settled:'freshness needs shared history or an equivalent transaction/version discipline'});

writeFileSync(new URL('./counterexample-results.json',import.meta.url),JSON.stringify({label:'RESULT, GENERATED; exact finite checks',checks:results.length,scope:'Specified finite toy models and upstream compose logic with evidence/parser stubs; no platform proof or complete repository test suite.',results},null,2)+'\n');
console.log(`All ${results.length} exact checks passed.`);

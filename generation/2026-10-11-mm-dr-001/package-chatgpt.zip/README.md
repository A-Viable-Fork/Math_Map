# MM-DR-001 D9 research package

The report contains the complete requested survey, proposal and audit.

The JSON files are GENERATED research proposals with source access limits.
They have not been installed in Math_Map or proved against a platform binding.
`carrier-proposal.json` explicitly requires a schema decision for conjunctive
operands and exact parameter/subject bindings.

Run `node counterexamples.mjs` after extraction to reproduce 11 exact finite
checks. Node's built-in modules are the only dependencies. The included
compose logic is from the recorded upstream blob with parser/evidence stubs
for isolation; this is not the full repository test suite. It does not test a
cryptographic implementation or provide a D9 security proof.

See `scaffold-snapshot.json` for the source identity and
`source-ledger.json` for individual bibliographic verification limits.

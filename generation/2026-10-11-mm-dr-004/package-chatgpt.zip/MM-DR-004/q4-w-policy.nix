# MM-DR-004, GENERATED module sketch; nixpkgs pin:
# 7c8764b7c7b09b34f632464276218ef9090eaa11 (NixOS 26.05).
# This is the conservative implementation: every worker permitted to read W
# belongs to W from launch. It does not implement floating process labels.
# UID values are example reservations; check the target host for collisions.
# All supplied paths, executable code and Nix store contents must be nonsecret
# except for /srv/research/W/{input,state}; all three must be local filesystems.
# Root, the owner, the kernel and PID 1 are trusted. Other booted OSes are outside
# this implementation. See the report for the exact guarantee and limitations.
{ lib, pkgs, ... }:
let
  workerUid = 61001;
  publicUid = 61002;
  rootDirectory = "/var/lib/research-w-root";
in
{
  users.groups.agent-w.gid = workerUid;
  users.groups.agent-public.gid = publicUid;
  users.users.agent-w = {
    uid = workerUid;
    isSystemUser = true;
    group = "agent-w";
    shell = "${pkgs.shadow}/bin/nologin";
  };
  users.users.agent-public = {
    uid = publicUid;
    isSystemUser = true;
    group = "agent-public";
    shell = "${pkgs.shadow}/bin/nologin";
  };

  # Does not import W bytes into a derivation or into /nix/store.
  systemd.tmpfiles.rules = [
    "d /srv/research 0755 root root - -"
    # Keep bind-source parents owned by the trusted administrator so a worker
    # cannot replace a source directory with a symlink before a service restart.
    "d /srv/research/W 0750 root agent-w - -"
    "d /srv/research/W/input 0750 root agent-w - -"
    "d /srv/research/W/state 0700 agent-w agent-w - -"
    "d ${rootDirectory} 0755 root root - -"
    "d ${rootDirectory}/nix 0755 root root - -"
    "d ${rootDirectory}/nix/store 0755 root root - -"
    "d ${rootDirectory}/w 0755 root root - -"
    "d ${rootDirectory}/state 0755 root root - -"
    "d ${rootDirectory}/run 0755 root root - -"
    "d ${rootDirectory}/tmp 0755 root root - -"
  ];

  # Avoid the host crash collector receiving worker memory. This has a global
  # effect and is explicit in this sketch. LimitCORE below prevents core files.
  systemd.coredump.enable = lib.mkForce false;
  boot.kernel.sysctl."kernel.core_pattern" = lib.mkForce "core";
  nix.settings.trusted-users = lib.mkForce [ "root" ];
  nix.settings.sandbox = true;
  nix.settings.sandbox-fallback = false;

  systemd.services.research-w = {
    description = "Local W compartment worker";
    wantedBy = [ "multi-user.target" ];
    after = [ "systemd-tmpfiles-setup.service" ];
    requires = [ "systemd-tmpfiles-setup.service" ];
    serviceConfig = {
      Type = "simple";
      User = "agent-w";
      Group = "agent-w";
      SupplementaryGroups = [ ];
      # Replace this inert placeholder with the audited local agent executable.
      # Its whole closure must work inside this root. Do not prefix it with '+'.
      ExecStart = "${pkgs.coreutils}/bin/sleep infinity";
      RootDirectory = rootDirectory;
      WorkingDirectory = "/state";
      BindReadOnlyPaths = [ "/nix/store" "/srv/research/W/input:/w" ];
      BindPaths = [ "/srv/research/W/state:/state" ];
      ProtectSystem = "strict";
      ReadWritePaths = [ "/state" ];
      ProtectHome = true;
      PrivateTmp = "disconnected";
      TemporaryFileSystem = [ "/run:mode=0700" "/dev/shm:mode=0700" ];
      PrivateIPC = true;
      PrivateDevices = true;
      DevicePolicy = "closed";
      PrivateNetwork = true;
      IPAddressDeny = "any";
      RestrictAddressFamilies = [ "AF_UNIX" ];
      RestrictNamespaces = true;
      NoNewPrivileges = true;
      CapabilityBoundingSet = [ ];
      AmbientCapabilities = [ ];
      ProtectControlGroups = true;
      ProtectKernelTunables = true;
      ProtectKernelModules = true;
      ProtectKernelLogs = true;
      ProtectClock = true;
      RestrictSUIDSGID = true;
      SystemCallArchitectures = "native";
      # socket-family seccomp filtering alone misses io_uring-created sockets.
      SystemCallFilter = [
        "~@mount @privileged @debug io_uring_setup io_uring_enter io_uring_register"
      ];
      SystemCallErrorNumber = "EPERM";
      Delegate = false;
      KillMode = "control-group";
      RemoveIPC = true;
      UMask = "0077";
      LimitCORE = 0;
      StandardInput = "null";
      StandardOutput = "null";
      StandardError = "null";
      Restart = "no";
    };
  };
}

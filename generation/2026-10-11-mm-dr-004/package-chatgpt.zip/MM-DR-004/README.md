# MM-DR-004 result package

Start with **MM-DR-004-report.md**. The full assessment is source inspection, not a deployed or device-tested policy.

- **bindings.json**: one array covering all 27 supplied operations, with multiple concrete variants.
- **q4-w-policy.nix**: GENERATED conservative always-W module; inert executable placeholder, not dynamic contamination runtime.
- **vocabulary-measurement.json**: minimal expressibility measurement and required semantics.
- **part-b-entries.json**, **candidate-invariants.json**: unassigned Nix-native candidate vocabulary.
- **enforcement-map.md**, **escape-channels.md**, **feasibility.md**: standalone tables.
- **versions.json**, **option-catalog.json**: platform/version and actual option-definition records.
- **receipts.json**, **source-index.md**, **source-manifest.json**: exact source hashes, URLs, release refs and cache locations.
- **sources/** and **inputs/**: successful source bytes and original input exports.
- **unverified-sources.json**: failed source probes, excluded from successful-read receipts/evidence.
- **validation.json**: executed structural/hash/syntax checks and explicit limits.

Timing/physical observations are excluded. No stock options-only dynamic IFC or full-system rollback/erasure/provenance theorem is claimed. Values in the Nix module such as UIDs, paths and executable must be reviewed against the actual host; the module is not enabled here.

# MM-DR-004 Q4 module sketch: W never leaves; W-reading processes emit as W until reset.
# Status: PARTIAL. The first clause has NixOS-native pieces. The second clause
# (per-process contamination) is not expressible as NixOS options alone.
{ config, lib, pkgs, ... }:
let
  agentUids = map (n: config.users.users.${n}.uid) config.researchOs.agents;
  anyAgent = lib.concatStringsSep ", " (map toString agentUids);
in
{
  options.researchOs = {
    agents = lib.mkOption { type = lib.types.listOf lib.types.str; default = [ ]; description = "Agent account names; each must also be created in users.users."; };
    wGid = lib.mkOption { type = lib.types.int; default = 2000; description = "Group owning W storage roots."; };
    wRoots = lib.mkOption { type = lib.types.listOf lib.types.str; default = [ "/var/lib/w" ]; description = "Machine-local roots for W data; never add a Nix store path or /tmp."; };
    taint = {
      runtimeRequired = lib.mkOption { type = lib.types.bool; default = true; description = "Set false only to build the static skeleton; enforcement is intentionally incomplete when false."; };
    };
  };

  config = lib.mkMerge [
    { users.groups.w.gid = config.researchOs.wGid;
      systemd.tmpfiles.rules = map (r: "d ${r} 0770 root w - -") config.researchOs.wRoots;
      # Keep W out of world-readable store paths and out of swap where possible.
      boot.kernel.sysctl."vm.swappiness" = lib.mkDefault 10;
      services.journald.extraConfig = "SystemMaxUse=200M\nForwardToSyslog=no";
      assertions = [ { assertion = config.researchOs.taint.runtimeRequired; message = "Q4 policy is intentionally not enforceable without the runtime contamination monitor; set researchOs.taint.runtimeRequired=false only for static testing."; } ];
    }

    # Egress: machine boundary for agent accounts. Localhost and session buses are not covered.
    (lib.mkIf (config.researchOs.agents != [ ]) {
      networking.nftables.enable = true;
      networking.nftables.ruleset = ''
        table inet w_egress {
          chain output {
            type filter hook output priority -10; policy accept;
            meta skuid { ${anyAgent} } oifname != "lo" reject with icmpx type admin-prohibited
            meta skuid { ${anyAgent} } ip daddr != 127.0.0.0/8 reject with icmp type admin-prohibited
            meta skuid { ${anyAgent} } ip6 daddr != ::1 reject with icmpx type no-route
          }
        }
      '';
      # If agents are systemd services, add per-unit directives too:
      # systemd.services.<agent>.serviceConfig = { IPAddressDeny = "any"; IPAddressAllow = "localhost"; RestrictAddressFamilies = "AF_UNIX"; PrivateNetwork = true; };
    })

    # Static separation skeleton; not sufficient for the contamination clause.
    (lib.mkIf (config.researchOs.agents != [ ]) {
      # Each agent account should get: isNormalUser, extraGroups, and services run under that uid.
      # Example:
      # users.users.agent-w = { isNormalUser = true; uid = 1001; };
      # systemd.services.agent-w = {
      #   serviceConfig = {
      #     User = "agent-w";
      #     Group = "w";
      #     ProtectHome = true;
      #     ProtectSystem = "strict";
      #     ReadWritePaths = [ "/var/lib/w/agent-w" ];
      #     PrivateTmp = true;
      #     PrivateNetwork = true;
      #     NoNewPrivileges = true;
      #     CapabilityBoundingSet = [ "" ];
      #     SystemCallFilter = [ "@system-service" "~@privileged" ];
      #   };
      # };
    })
  ];
}
